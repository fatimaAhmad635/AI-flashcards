import { NextResponse } from 'next/server'
import OpenAI from 'openai'

// Initialize OpenAI with your API key
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

const systemPrompt = `
You are a flashcard creator. You take in text and create exactly 10 flashcards from it.
Each flashcard should have one sentence for both the front and back.
Return the flashcards in the following JSON format:
{
  "flashcards": [
    {
      "front": "Front of the card",
      "back": "Back of the card"
    }
  ]
}
`

export async function POST(req) {
  try {
    const text = await req.text()

    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: text },
      ],
      max_tokens: 500,
      temperature: 0.7,
    })

    const generatedText = response.choices[0].message.content

    // Parse the generated JSON and return it
    const flashcards = JSON.parse(generatedText)

    return NextResponse.json(flashcards, {
      status: 200,
    })
  } catch (error) {
    console.error('Error generating flashcards:', error)
    return NextResponse.json({ error: { message: error.message } }, { status: 500 })
  }
}