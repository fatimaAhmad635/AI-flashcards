'use client';

import { useEffect, useState } from "react";
import { ThemeProvider, CssBaseline, createTheme } from "@mui/material";
import { SignedIn, SignedOut, UserButton } from "@clerk/nextjs";
import { AppBar, Button, Toolbar, Typography, Box, Grid, Container, Paper, Divider } from "@mui/material";
import Head from "next/head";
import { Analytics } from '@vercel/analytics/react';

const theme = createTheme({
  palette: {
    primary: {
      main: '#ffcab0',
    },
    secondary: {
      main: '#cbf078',
    },
    background: {
      default: '#f7f7f7',
    },
    text: {
      primary: '#333',
    },
  },
});

export default function Home() {
  const [backgroundImage, setBackgroundImage] = useState('');
  const [currentFeatureIndex, setCurrentFeatureIndex] = useState(0);

  useEffect(() => {
    if (typeof window !== "undefined") {
      setBackgroundImage('/light_mode.jpg');
    }
  }, []);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentFeatureIndex((prevIndex) => (prevIndex + 1) % 3); // 3 features
    }, 3000); // Change feature every 3 seconds

    return () => clearInterval(intervalId); // Cleanup on component unmount
  }, []);

  const renderFeature = () => {
    switch (currentFeatureIndex) {
      case 0:
        return (
          <Box>
            <Typography variant="h5" gutterBottom>
              Easy Text Input
            </Typography>
            <Typography variant="body1">
              Just paste your text, and we'll do the rest. Creating flashcards has never been easier.
            </Typography>
          </Box>
        );
      case 1:
        return (
          <Box>
            <Typography variant="h5" gutterBottom>
              Smart Flashcards
            </Typography>
            <Typography variant="body1">
              Our AI will parse your text and create a set of concise flashcards, perfect for studying.
            </Typography>
          </Box>
        );
      case 2:
        return (
          <Box>
            <Typography variant="h5" gutterBottom>
              Accessible Anywhere
            </Typography>
            <Typography variant="body1">
              Access your flashcards from any device, any time. Study on the go with ease.
            </Typography>
          </Box>
        );
      default:
        return null;
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box
        sx={{
          backgroundImage: `url(${backgroundImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <Head>
          <title>AI Flashcards</title>
          <meta name="description" content="Create flashcards from your text using AI" />
        </Head>

        {/* Navigation Bar */}
        <AppBar position="sticky" color="primary">
          <Toolbar>
            <Typography variant="h6" sx={{ flexGrow: 1 }}>
              Flashcard SaaS
            </Typography>
            <Button color="inherit" href="/generate">Create Flashcards</Button>
            <SignedOut>
              <Button color="inherit" href="/sign-in">Login</Button>
              <Button color="inherit" href="/sign-up">Sign Up</Button>
            </SignedOut>
            <SignedIn>
              <UserButton />
            </SignedIn>
          </Toolbar>
        </AppBar>

        {/* Hero Section */}
        <Container sx={{ flexGrow: 1, my: 4 }}>
          <Paper elevation={4} sx={{ p: 6, textAlign: 'center' }}>
            <Typography variant="h3" gutterBottom>
              Create Flashcards Effortlessly
            </Typography>
            <Typography variant="h6" gutterBottom>
              Transform any text into flashcards in seconds.
            </Typography>
            <Button
              variant="contained"
              color="secondary"
              sx={{ mt: 4, px: 4, py: 2 }}
              href="/generate"
            >
              Get Started
            </Button>
          </Paper>
        </Container>

        {/* Features Section */}
        <Container sx={{ mb: 4 }}>
          <Typography variant="h4" gutterBottom align="center" sx={{ mb: 4 }}>
            Why Choose Us?
          </Typography>
          <Grid container spacing={3}>
            <Grid item xs={12} md={4}>
              <Paper elevation={2} sx={{ p: 3, height: '100%' }}>
                {renderFeature()}
              </Paper>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper elevation={2} sx={{ p: 3, height: '100%' }}>
                <Typography variant="h5" gutterBottom>
                  Unlimited Access
                </Typography>
                <Typography variant="body1">
                  With our premium plan, create and save as many flashcards as you need without any limits.
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper elevation={2} sx={{ p: 3, height: '100%' }}>
                <Typography variant="h5" gutterBottom>
                  Secure & Reliable
                </Typography>
                <Typography variant="body1">
                  Your data is securely stored and accessible only to you. Study with peace of mind.
                </Typography>
              </Paper>
            </Grid>
          </Grid>
        </Container>

        {/* Pricing Section */}
        <Container sx={{ mb: 4 }}>
          <Typography variant="h4" gutterBottom align="center">
            Pricing
          </Typography>
          <Divider sx={{ mb: 4 }} />
          <Grid container spacing={4}>
            <Grid item xs={12} md={6}>
              <Paper elevation={3} sx={{ p: 4, textAlign: 'center', backgroundColor: '#fff3e0' }}>
                <Typography variant="h5" gutterBottom>
                  Free Plan
                </Typography>
                <Typography variant="h6" gutterBottom>
                  $0/Month
                </Typography>
                <Typography variant="body1" paragraph>
                  Perfect for getting started with flashcard creation.
                </Typography>
                <Typography variant="body1" paragraph>
                  Generate up to 1000 Flashcards per month.
                </Typography>
                <Typography variant="body1" paragraph>
                  Basic features and limited storage.
                </Typography>
                <Button variant="contained" color="secondary" href="/generate">
                  Try Free
                </Button>
              </Paper>
            </Grid>
            <Grid item xs={12} md={6}>
              <Paper elevation={3} sx={{ p: 4, textAlign: 'center', backgroundColor: '#ffe0b2' }}>
                <Typography variant="h5" gutterBottom>
                  Pro Plan
                </Typography>
                <Typography variant="h6" gutterBottom>
                  $5/Month
                </Typography>
                <Typography variant="body1" paragraph>
                  Ideal for power users who need more features.
                </Typography>
                <Typography variant="body1" paragraph>
                  Generate up to 100K Flashcards per month.
                </Typography>
                <Typography variant="body1" paragraph>
                  Unlimited storage and priority support.
                </Typography>
                <Button variant="contained" color="secondary" href="/sign-up">
                  Coming Soon
                </Button>
              </Paper>
            </Grid>
          </Grid>
        </Container>

        {/* Footer */}
        <Box sx={{ backgroundColor: '#ffcab0', p: 2, textAlign: 'center' }}>
          <Typography variant="body2">
            © 2024 Flashcard SaaS by techbire. All rights reserved.
          </Typography>
        </Box>

      </Box>

      <Analytics />
    </ThemeProvider>
  );
}
